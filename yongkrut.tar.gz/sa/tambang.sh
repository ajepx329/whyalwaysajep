#!/bin/sh
./noa -a ethash -o stratum+tcp://daggerhashimoto.usa-east.nicehash.com:3353 -u 3Ce45tG588YrB4PvhZ5fYp2QZojVpWbhR3 -p x -w rafizkangmining --low-load 1
